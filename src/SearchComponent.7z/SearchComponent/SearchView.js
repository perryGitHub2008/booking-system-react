import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import CheckInCheckOutPicker from '../Component/CheckInCheckOutPicker';
import DestinationAutoComplete from '../Component/DestinationAutoComplete';
import RoomSelector from '../Component/RoomSelector';
import SearchFilterBar from './SearchFilterBar';
import PropertyList from './PropertyList';
function SearchView(props){

    return (
        <Grid container>
            <Grid item xs={12}>
                <Grid 
                container 
                justifyContent="center"
                alignItems="center"
                sx={{py:1, background:'rgb(158, 158, 158,.3)'}}
                >
                    <Grid item xs={3}>
                        <DestinationAutoComplete/>
                    </Grid>
                    <Grid item xs={3} sx={{ml:3}}>
                        <CheckInCheckOutPicker/>
                    </Grid>
                    <Grid item xs={2}>
                        <RoomSelector/>
                    </Grid>
                    <Grid item xs={1}>
                        <Button variant="contained" sx={{ml:3,height:'56px', width:'100%'}}>Search</Button>
                    </Grid>
                </Grid>
            </Grid>
            <Grid item xs={12}>
                <SearchFilterBar/>
            </Grid>
            <Grid item xs={12} sx={{py:2}}>
                <PropertyList/>
            </Grid>
        </Grid>
    );
}

export default SearchView;
