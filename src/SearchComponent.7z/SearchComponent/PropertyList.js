import Box from '@mui/material/Box';
import Tooltip from '@mui/material/Tooltip';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import Grid from '@mui/material/Grid';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Rating from '@mui/material/Rating';
import hotel1 from './HotelImage/7437_15081117200034063157.jpg'
import hotel2 from './HotelImage/21211583ed575afea1b20b5f27bfc090.jpg'
import hotel3 from './HotelImage/254048767.jpg'
import hotel4 from './HotelImage/a56dffde46736eb24ff1c696a507e660.jpg'
import hotel5 from './HotelImage/265070656.jpg'
import AddLocationIcon from '@mui/icons-material/AddLocation';

function srcset(image, size, rows = 1, cols = 1) {
    return {
        src: `${image}?w=${size * cols}&h=${size * rows}&fit=crop&auto=format`,
        srcSet: `${image}?w=${size * cols}&h=${
            size * rows
        }&fit=crop&auto=format&dpr=2 2x`,
    };
}
function PropertyList(){

    
   
    const properties = [
        {name:'The Hari Hong Kong', 
        star:5, 
        address:'Wanchai, Hong Kong - 1.6 km to center',
        price:'2301', 
        discount:55, 
        rating:[9,8.5,8.5,8.4,8.4], 
        image:[{img:hotel1, title:'1', rows:4, cols:4},
                {img:hotel2, title:'1',},
                {img:hotel3, title:'1',},
                {img:hotel4, title:'1',},
                {img:hotel5, title:'1',}
            ]}]

        const totalTraveler =()=>{
            const adults = []
            properties.map((property)=>{
                return(
                adults.push( property.rating.reduce((prev, curr)=>{
                    return prev + curr},0))
            )})
            return adults

        }

    
    return (
        
        <Grid container justifyContent="center">
            <Grid item xs={2.3}></Grid>
            {properties.map((property,index) => {
                return(
                    <Grid item xs={7}>
                        <Card sx={{ display: 'flex' }}>
                            <ImageList
                            sx={{ width: 273, height: 221, m:0}}
                            variant="quilted"
                            cols={4}
                            rowHeight={41}
                            >
                                {property.image.map((imageItem)=>{
                                    return(
                                        <ImageListItem
                                        key={imageItem.img}
                                        cols={imageItem.cols || 1}
                                        rows={imageItem.rows || 1}
                                        >
                                        <img
                                            {...srcset(imageItem.img, 182, imageItem.rows, imageItem.cols)}
                                            alt={imageItem.title}
                                            loading="lazy"
                                        />
                                        </ImageListItem>
                                    );
                                })}
                            </ImageList>
                            <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                                <CardContent sx={{ flex: '1 0 auto' }}>
                                    <Typography component="div" variant="h5">
                                        {property.name}
                                    </Typography>
                                    <Box sx={{ display: 'flex'}}>
                                        <Rating name="readOnly" value={property.star} readOnly size='small' />
                                        <AddLocationIcon color="primary" fontSize="small"/>
                                        <Typography  variant="caption" color="text.secondary">
                                            {property.address}
                                        </Typography>
                                    </Box>
                                </CardContent>
                            </Box>
                            <Divider orientation="vertical" flexItem />
                            <Tooltip title="Delete">
                                <Box sx={{width:'225px', display: 'flex', justifyContent: 'flex-end' }}>
                                    {totalTraveler()[index]>8 ? `Excellent${totalTraveler()[index]}`:''}
                                    <Avatar sx={{ width: 24, height: 24 }}>
                                        {totalTraveler()[index]}
                                    </Avatar>
                                </Box>
                            </Tooltip >
                        </Card>
                    </Grid>
                );
            })}
        </Grid>
    );
}

export default PropertyList;

